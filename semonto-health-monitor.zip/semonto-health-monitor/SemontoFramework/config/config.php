<?php
//build the config file
function  getConfig() {
    return generate_semonto_config();
}